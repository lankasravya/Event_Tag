﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EventPlatformV3.Models
{
    public class LocationTypeKeys
    {
        [Key]
        public Nullable<int> LocationTypeID { get; set; }
    }
    public class LocationType : LocationTypeKeys
    {
        public string Name { get; set; }

        public Nullable<int> ParentID { get; set; }

        //public List<LocationType> LocationTypes { get; set; }
    }
}