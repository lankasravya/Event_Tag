﻿using EventPlatformV3.Models;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class Event_GenreKeys : ModificationDetails
    {
        [Key]
        public Nullable<int> Event_GenreID { get; set; }
    }
    public class Event_Genre : Event_GenreKeys
    {
        public int? EventID { get; set; }

        public int? GenreID { get; set; }

        public bool Prime { get; set; }

       [ForeignKey("EventID")]
        public Event Event { get; set; }

       [ForeignKey("GenreID")]
        public Genre Genre { get; set; }
    }
}