﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class Organisation_AddressKeys : ModificationDetails
    {
        [Keys]
        public Nullable<int> Organisation_AddressID { get; set; }
    }
    public class Organisation_Address : Organisation_AddressKeys
    {
        public int? OrganisationID { get; set; }

        public int? AddressID { get; set; }


        public int? OrganisationAddress_LuValueID { get; set; }
        public bool Publish { get; set; }

        [ForeignKey("OrganisationID")]
        public Organisation Organisation { get; set; }
    }
}
