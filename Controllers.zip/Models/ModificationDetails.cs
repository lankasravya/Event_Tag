﻿using System;

namespace EventPlatformV3.Models
{
    public class ModificationDetails : CreationDetails
    {
        public string ModifiedBy { get; set; }

        public DateTime? ModifiedDate { get; set; }
    }
}
