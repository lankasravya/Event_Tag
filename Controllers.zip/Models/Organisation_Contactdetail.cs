﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class Organisation_ContactdetailKeys : ModificationDetails
    {
        [Keys]
        public Nullable<int> Organisation_ContactDetailID { get; set; }
    }
    public class Organisation_Contactdetail : Organisation_ContactdetailKeys
    {
        public int? OrganisationID { get; set; }

        public int? ContactDetailID { get; set; }

        [ForeignKey("OrganisationID")]
        public Organisation Organisation { get; set; }
    }
}
