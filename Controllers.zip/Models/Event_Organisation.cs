﻿using EventPlatformV3.Models;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class Event_OrganisationKeys : ModificationDetails
    {
        public Nullable<int> Event_OrganisationID { get; set; }
    }
    public class Event_Organisation : Event_OrganisationKeys
    {
        public Nullable<int> EventID { get; set; }

        public Nullable<int> OrganizationID { get; set; }

        public Nullable<int> EventOrganisation_LuValueID { get; set; }

       [ForeignKey("EventID")]
        public Event Event { get; set; }

    }
}