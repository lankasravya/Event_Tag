﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EventPlatformV3.Models
{
    public class GenreTypeKeys
    {
        [Key]
        public Nullable<int> GenreTypeID { get; set; }
    }
    public class GenreType : GenreTypeKeys
    {
        public string Name { get; set; }

        public Nullable<int> ParentID { get; set; }

        //public List<Genre> Genres { get; set; }
    }
}