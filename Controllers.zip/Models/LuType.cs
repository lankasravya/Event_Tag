﻿using EventPlatformV3.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EventPlatformV3.Models
{
    public class LuTypeKeys : ModificationDetails
    {
        [Key]
        public Nullable<int> LuTypeID { get; set; }
    }
    public class LuType : LuTypeKeys
    {
        public string Name { get; set; }

        //public List<LuValue> LuValues { get; set; }
    }
}