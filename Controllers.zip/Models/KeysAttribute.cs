﻿using System;

namespace EventPlatformV3.Models
{
    internal class KeysAttribute : Attribute
    {
    }
}