﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class Person_ContactdetailKeys : ModificationDetails
    {
        [Keys]
        public Nullable<int> Person_ContactDetailID { get; set; }
    }
    public class Person_Contactdetail : Person_ContactdetailKeys
    {
        public int? PersonID { get; set; }

        public int? ContactDetailID { get; set; }
                
        [ForeignKey("PersonID")]
        public Person Person { get; set; }
    }
}
