﻿using EventPlatformV3.Models;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class EventEditionStatusKeys : ModificationDetails
    {
        [Key]
        public Nullable<int> EventEditionStatusID { get; set; }
    }
    public class EventEditionStatus : EventEditionStatusKeys
    {
        public Nullable<int> EventEditionID { get; set; }

        public Nullable<int> EventEditionStatus_LuValueID { get; set; }

        public DateTime? DateStamp { get; set; }

        public string Notes { get; set; }

        [ForeignKey("EventEditionID")]
        public EventEdition EventEdition { get; set; }

    }
}