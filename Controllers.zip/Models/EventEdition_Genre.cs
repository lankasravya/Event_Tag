﻿using EventPlatformV3.Models;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class EventEdition_GenreKeys : ModificationDetails
    {
        [Key]
        public Nullable<int> EventEdition_GenreID { get; set; }
    }
    public class EventEdition_Genre : EventEdition_GenreKeys
    {
        public Nullable<int> EventEditionID { get; set; }

        public Nullable<int> GenreID { get; set; }

        public bool Prime { get; set; }

        [ForeignKey("EventEditionID")]
        public EventEdition EventEdition { get; set; }

        [ForeignKey("EventType_AnalysisID")]
        public Genre Genre { get; set; }

    }
}