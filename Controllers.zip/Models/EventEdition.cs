﻿using EventPlatformV3.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
	public class EventEditionKeys : ModificationDetails
	{
		[Key]
		public Nullable<int> EventEditionID { get; set; }
	}

	public class EventEdition : EventEditionKeys
    {
		public string Name { get; set; }

		public string SubName { get; set; }

		public string AltName { get; set; }

		public Nullable<int> EventID { get; set; }

		public DateTime? StartDate { get; set; }

		public DateTime? FinishDate { get; set; }

		public Nullable<int> length { get; set; }

		public Nullable<int> TimeZone_LuValue { get; set; }

		public bool DateConfirmed { get; set; }

		public bool Publish { get; set; }

		public string PublishedBy { get; set; }

		public DateTime? PublishedDate { get; set; }

		[ForeignKey("EventID")]
		public Event Event { get; set; }

		//public List<EventEdition_Genre> EventEdition_Genres { get; set; }

		//public List<EventEdition_Location> EventEdition_Locations { get; set; }

		//public List<EventEdition_Organisation> EventEdition_Organisations { get; set; }

		//public List<EventEditionStatus> EventEditionStatuses { get; set; }

	}
}