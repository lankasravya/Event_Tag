﻿using EventPlatformV3.Models;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class EventEdition_LocationKeys : ModificationDetails
    {
        [Key]
        public Nullable<int> EventEdition_LocationID { get; set; }
    }
    public class EventEdition_Location : EventEdition_LocationKeys
    {
        public Nullable<int> EventEditionID { get; set; }

        public Nullable<int> LocationID { get; set; }

        public bool Prime { get; set; }

       [ForeignKey("LocationID")]
        public Location Location { get; set; }

       [ForeignKey("EventEditionID")]
        public EventEdition EventEdition { get; set; }

    }
}