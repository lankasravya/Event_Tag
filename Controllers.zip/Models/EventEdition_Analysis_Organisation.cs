﻿using EventPlatformV3.Models;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class EventEdition_Analysis_OrganisationKeys : ModificationDetails
    {
        [Key]
        public Nullable<int> EventType_Analysis_OrganisationID { get; set; }
    }
    public class EventEdition_Analysis_Organisation : EventEdition_Analysis_OrganisationKeys
    {
        public Nullable<int> EventType_AnalysisID { get; set; }

        public Nullable<int> OrganisationID { get; set; }

        public Nullable<int> EventTypeAnalysisOrganisation_LuValueID { get; set; }

       [ForeignKey("EventType_AnalysisID")]
        public EventType_Analysis EventType_Analysis { get; set; }

    }
}