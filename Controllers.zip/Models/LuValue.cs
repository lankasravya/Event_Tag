﻿using EventPlatformV3.Models;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class LuValueKeys : ModificationDetails
    {
        [Key]
        public Nullable<int> LuValueID { get; set; }
    }

    public class LuValue : LuValueKeys
    {
        public string Name { get; set; }

        public Nullable<int> LuTypeID { get; set; }

        public string Code { get; set; }

        public string Placeholder { get; set; }

        public Nullable<int> SortOrder { get; set; }

        public bool Publish { get; set; }

        [ForeignKey("LuTypeID")]
        public LuType LuType { get; set; }
    }
}