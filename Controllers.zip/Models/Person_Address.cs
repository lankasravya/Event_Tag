﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class Person_AddressKeys : ModificationDetails
    {
        [Keys]
        public Nullable<int> Person_AddressID { get; set; }
    }
    public class Person_Address : Person_AddressKeys
    {
        public int? PersonID { get; set; }

        public int? AddressID { get; set; }


        public int? PersonAddress_LuValueID { get; set; }
        
        public bool Publish { get; set; }

        [ForeignKey("PersonID")]
        public Person Person { get; set; }
    }
}
