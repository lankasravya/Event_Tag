﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class Organisation_CategoryKeys : ModificationDetails
    {
        [Keys]
        public Nullable<int> Organisation_CategoryID { get; set; }
    }
    public class Organisation_Category : Organisation_CategoryKeys
    {
        public int? OrganisationID { get; set; }

        public int? CategoryID { get; set; }
        public bool Prime { get; set; }

        [ForeignKey("OrganisationID")]
        public Organisation Organisation { get; set; }
    }
}
