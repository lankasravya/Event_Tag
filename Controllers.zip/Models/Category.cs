﻿using EventPlatformV3.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EventPlatformV3.Models
{
    public class CategoryKeys: ModificationDetails
    {
        [Key]
        public Nullable<int> CategoryID { get; set; }
    }
    public class Category : CategoryKeys
    {
        public string Name { get; set; }

        public Nullable<int> ParentID { get; set; }
        //public List<Event_Category> EventCategories { get; set; }
    }
}
