﻿using EventPlatformV3.Models;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class EventEdition_OrganisationKeys : ModificationDetails
    {
        [Key]
        public Nullable<int> EventEdition_OrganisationID { get; set; }
    }
    public class EventEdition_Organisation : EventEdition_OrganisationKeys
    {
        public Nullable<int> EventEditionID { get; set; }

        public Nullable<int> OrganisationID { get; set; }

        public Nullable<int> EventEditionOrganisation_LuValueID { get; set; }

       [ForeignKey("EventEditionID")]
        public EventEdition EventEdition { get; set; }

    }
}