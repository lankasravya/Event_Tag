﻿using EventPlatformV3.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class EventType_AnalysisKeys : ModificationDetails
    {
        [Key]
        public Nullable<int> EventType_AnalysisID { get; set; }
    }
    public class EventType_Analysis : EventType_AnalysisKeys
    {
        public Nullable<int> EventTypeID { get; set; }

        public Nullable<int> AnalysisID { get; set; }

        public Nullable<int> EventType_LuValueID { get; set; }

        public bool Publish { get; set; }

       [ForeignKey("AnalysisID")]
        public Analysis Analysis { get; set; }

        //public List<EventEdition_Analysis_Organisation> EventEdition_Analysis_Organisations { get; set; }

    }
}