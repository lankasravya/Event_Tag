﻿using System;

namespace EventPlatformV3.Models
{
    public class PersonKeys : ModificationDetails
    {
        [Keys]
        public Nullable<int> PersonID { get; set; }
    }
    public class Person : PersonKeys
    {
        public int? Salutation_LuValueID { get; set; }

        public string Firstname { get; set; }

        public string Lastname { get; set; }

        public int? LocationID { get; set; }

        public DateTime? DOB { get; set; }

        public string Gender { get; set; }

        public string Jobtitle { get; set; }
        public bool Publish { get; set; }
        public bool Active { get; set; }

       
    }
}
