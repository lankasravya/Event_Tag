﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class Organisation_PersonKeys : ModificationDetails
    {
        [Keys]
        public Nullable<int> Organisation_PersonID { get; set; }
    }
    public class Organisation_Person : Organisation_PersonKeys
    {
        public int? OrganisationID { get; set; }

        public int? PersonID { get; set; }

        public int? OrganisationPerson_LuValueID { get; set; }

        public DateTime? Startdate { get; set; }

        public DateTime? Finishdate { get; set; }
        public bool Publish { get; set; }
        public bool Active { get; set; }
        public bool Prime { get; set; }

        [ForeignKey("OrganisationID")]
        public Organisation Organisation { get; set; }
    }
}
