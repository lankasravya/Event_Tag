﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EventPlatformV3.Models
{
    public class Organisationkeys: ModificationDetails
    {
        [Key]
        public Nullable<int> OrganisationID { get; set; }
    }
    public class Organisation : Organisationkeys
    {
        public string Name { get; set; }

        public string SubName { get; set; }
        
        public string AltName { get; set; }
        public bool Publish { get; set; }

        public bool Active { get; set; }

        
    }
}
