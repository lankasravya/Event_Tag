﻿using EventPlatformV3.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class GenreKeys : ModificationDetails
    {
        [Key]
        public Nullable<int> GenreID { get; set; }
    }
    public class Genre : GenreKeys
    {
        public string Name { get; set; }

        public int? ParentID { get; set; }

        public int? GenreTypeID { get; set; }

        //public List<Event_Genre> EventGenres { get; set; }

       [ForeignKey("GenreTypeID")]
        public GenreType GenreType { get; set; }

        //public List<EventEdition_Genre> EventEdition_Genres { get; set; }

    }
}