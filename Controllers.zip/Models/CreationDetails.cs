﻿using System;

namespace EventPlatformV3.Models
{
    public class CreationDetails
    {
        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }
    }
}
