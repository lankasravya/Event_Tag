﻿using EventPlatformV3.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EventPlatformV3.Models
{
    public class EventKeys : ModificationDetails
    {
        [Key]
        public Nullable<int> EventID { get; set; }
    }
    public class Event: EventKeys
    {
        public string Name { get; set; }

        public string SubName { get; set; }

        public string AltName { get; set; }

        public Nullable<int> StartYear { get; set; }

        public Nullable<int> FinishYear { get; set; }

        public Nullable<int> Frequency_LuValueID { get; set; }

        public Nullable<bool> Publish { get; set; }

        public Nullable<bool> Active { get; set; }

        //public List<Event_Category> EventCategories { get; set; }

        //public List<Event_Genre> EventGenres { get; set; }

        //public List<Event_Organisation> Event_Organisations { get; set; }

        //public List<EventEdition> EventEditions { get; set; }

    }
}