﻿using EventPlatformV3.Models;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class Event_CategoryKeys: ModificationDetails
    {
        [Key]
        public Nullable<int> Event_CategoryID { get; set; }
    }
    public class Event_Category : Event_CategoryKeys
    {
        public int?  EventID { get; set; }

        public int? CategoryID { get; set; }

        public bool Prime { get; set; }

        [ForeignKey("EventID")]
        public Event Event { get; set; }

        [ForeignKey("CategoryID")]
        public Category Category { get; set; }

    }
}