﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class EventEdition_CategoryKeys : ModificationDetails
    {
        [Keys]
        public Nullable<int> EventEdition_CategoryID { get; set; }
    }
    public class EventEdition_Category : EventEdition_CategoryKeys
    {
        public int? EventEditionID { get; set; }

        public int? CategoryID { get; set; }

        public bool Prime { get; set; }

        [ForeignKey("EventEditionID")]
        public EventEdition EventEdition  { get; set; }

        [ForeignKey("CategoryID")]
        public Category Category { get; set; }

    }
}
