﻿using EventPlatformV3.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EventPlatformV3.Models
{
    public class AnalysisKeys : ModificationDetails
    {
        [Key]
        public Nullable<int> AnalysisID { get; set; }
    }

    public class Analysis : AnalysisKeys
    {
        public string Name { get; set; }

        public Nullable<int> ParentID { get; set; }

        public Nullable<int> DataType_LuValueID { get; set; }

        public Nullable<int> SortOrder { get; set; }

        public bool Publish { get; set; }

        //public string ModifiedBy { get; set; }

        //public DateTime? ModifiedDate { get; set; }

        //public string CreatedBy { get; set; }

        //public DateTime? CreatedDate { get; set; }

        //public List<EventType_Analysis> EventType_Analyses { get; set; }
    }
}