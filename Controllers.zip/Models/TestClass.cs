﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EventPlatformV3.Models
{
    public class TestClass
    {
        public string Name { get; set; }

        [Key]
        public Nullable<int> LuTypeID { get; set; }

        public string Code { get; set; }

        public string Placeholder { get; set; }

        public Nullable<int> SortOrder { get; set; }

        public bool Publish { get; set; }
    }
}
