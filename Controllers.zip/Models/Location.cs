﻿using EventPlatformV3.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class LocationKeys : ModificationDetails
    {
        [Key]
        public Nullable<int> LocationID { get; set; }
    }
    public class Location : LocationKeys
    {
        public string Name { get; set; }

        public Nullable<int> ParentID { get; set; }

        public Nullable<int> LocationTypeID { get; set; }

      [ForeignKey("LocationTypeID")]
        public LocationType LocationType { get; set; }

        //public List<EventEdition_Location> EventEdition_Locations { get; set; }

    }
}