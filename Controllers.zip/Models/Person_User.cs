﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventPlatformV3.Models
{
    public class Person_UserKeys : ModificationDetails
    {
        [Keys]
        public Nullable<int> Person_UserID { get; set; }
    }
    public class Person_User : Person_UserKeys
    {
        public int? PersonID { get; set; }

        public int? OrganisationID { get; set; }
        public string UserID { get; set; }
        public bool Active { get; set; }

        [ForeignKey("PersonID")]
        public Person Person { get; set; }
        [ForeignKey("OrganisationID")]
        public Organisation Organisation { get; set; }
    }
}
