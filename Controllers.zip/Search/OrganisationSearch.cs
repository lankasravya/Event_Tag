﻿namespace EventPlatformV3.Search
{
    public class OrganisationSearch
    {
        public int? OrganisationID { get; set; }

        public int? LocationId { get; set; }

        public int? CategoryID { get; set; }

        public bool? Publish { get; set; }

        public bool? Active { get; set; }
    }
}
