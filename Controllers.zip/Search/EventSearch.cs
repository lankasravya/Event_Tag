﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EventPlatformV3.Search
{
    public class EventSearch
    {
        public int? GenreID { get; set; }

        public string? Name { get; set; }

        public int? CategoryID { get; set; }

        public int? StartYear { get; set; }

        public int? Frequency { get; set; }

        public bool? Publish { get; set; }

        public bool? Active { get; set; }

    }
}
