﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EventPlatformV3.Search
{
    public class EventEditionSearch
    {
        public int? GenreId { get; set; }

        public string? EventName { get; set; }

        public int? LocationId { get; set; }

        public int? EventEditionId { get; set; }

        public int? EventEditionOrganisationId { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? FinishDate { get; set; }

        public bool? Publish { get; set; }

        public bool? Active { get; set; }

    }
}
