﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GenreTypesController : ControllerBase
    {
        private readonly NewDBContext _context;

        public GenreTypesController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/GenreTypes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GenreType>>> GetGenreType()
        {
            return await _context.GenreType.ToListAsync();
        }

        // GET: api/GenreTypes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<GenreType>> GetGenreType(int id)
        {
            var genreType = await _context.GenreType.FindAsync(id);

            if (genreType == null)
            {
                return NotFound();
            }

            return genreType;
        }

        // PUT: api/GenreTypes/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutGenreType(GenreType genreType)
        {
            //if (id != genreType.GenreTypeID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(genreType).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!GenreTypeExists(Convert.ToInt32(genreType.GenreTypeID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/GenreTypes
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<GenreType>> PostGenreType(GenreType genreType)
        {
            _context.GenreType.Add(genreType);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetGenreType", new { id = genreType.GenreTypeID }, genreType);
        }

        // DELETE: api/GenreTypes/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<GenreType>> DeleteGenreType(int id)
        {
            var genreType = await _context.GenreType.FindAsync(id);
            if (genreType == null)
            {
                return NotFound();
            }

            _context.GenreType.Remove(genreType);
            await _context.SaveChangesAsync();

            return genreType;
        }

        private bool GenreTypeExists(int id)
        {
            return _context.GenreType.Any(e => e.GenreTypeID == id);
        }
    }
}
