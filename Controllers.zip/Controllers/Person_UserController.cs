﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Person_UserController : ControllerBase
    {
        private readonly NewDBContext _context;

        public Person_UserController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/Person_User
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Person_User>>> GetPerson_User()
        {
            return await _context.Person_User.ToListAsync();
        }

        // GET: api/Person_User/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Person_User>> GetPerson_User(int? id)
        {
            var person_User = await _context.Person_User.FindAsync(id);

            if (person_User == null)
            {
                return NotFound();
            }

            return person_User;
        }

        // PUT: api/Person_User/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutPerson_User(Person_User person_User)
        {
            //if (id != person_User.Person_UserID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(person_User).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Person_UserExists(Convert.ToInt32(person_User.Person_UserID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Person_User
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<Person_User>> PostPerson_User(Person_User person_User)
        {
            _context.Person_User.Add(person_User);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetPerson_User", new { id = person_User.Person_UserID }, person_User);
        }

        // DELETE: api/Person_User/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Person_User>> DeletePerson_User(int? id)
        {
            var person_User = await _context.Person_User.FindAsync(id);
            if (person_User == null)
            {
                return NotFound();
            }

            _context.Person_User.Remove(person_User);
            await _context.SaveChangesAsync();

            return person_User;
        }

        private bool Person_UserExists(int? id)
        {
            return _context.Person_User.Any(e => e.Person_UserID == id);
        }
    }
}
