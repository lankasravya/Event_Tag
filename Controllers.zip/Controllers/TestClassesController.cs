﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Data;
using EventPlatformV3.Models;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestClassesController : ControllerBase
    {
        private readonly NewDBContext _context;

        public TestClassesController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/TestClasses
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TestClass>>> GetTestClass()
        {
            return await _context.TestClass.ToListAsync();
        }

        // GET: api/TestClasses/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TestClass>> GetTestClass(int? id)
        {
            var testClass = await _context.TestClass.FindAsync(id);

            if (testClass == null)
            {
                return NotFound();
            }

            return testClass;
        }

        // PUT: api/TestClasses/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTestClass(int? id, TestClass testClass)
        {
            if (id != testClass.LuTypeID)
            {
                return BadRequest();
            }

            _context.Entry(testClass).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TestClassExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/TestClasses
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<TestClass>> PostTestClass(TestClass testClass)
        {
            _context.TestClass.Add(testClass);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTestClass", new { id = testClass.LuTypeID }, testClass);
        }

        // DELETE: api/TestClasses/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<TestClass>> DeleteTestClass(int? id)
        {
            var testClass = await _context.TestClass.FindAsync(id);
            if (testClass == null)
            {
                return NotFound();
            }

            _context.TestClass.Remove(testClass);
            await _context.SaveChangesAsync();

            return testClass;
        }

        private bool TestClassExists(int? id)
        {
            return _context.TestClass.Any(e => e.LuTypeID == id);
        }
    }
}
