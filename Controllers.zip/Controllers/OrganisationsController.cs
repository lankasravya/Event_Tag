﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Search;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrganisationsController : ControllerBase
    {
        private readonly NewDBContext _context;

        public OrganisationsController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/Organisations
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Organisation>>> GetOrganisation()
        {
            return await _context.Organisation.ToListAsync();
        }

        // GET: api/Organisations/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Organisation>> GetOrganisation(int? id)
        {
            var organisation = await _context.Organisation.FindAsync(id);

            if (organisation == null)
            {
                return NotFound();
            }

            return organisation;
        }

        [HttpGet]
        [Route("OrganisationSearch")]
        public async Task<ActionResult<IEnumerable<Organisation>>> GetOrganisation(OrganisationSearch organisationSearch)
        {
            List<Organisation> @organisation = new List<Organisation>();
            bool setData = false;
            if (organisationSearch.OrganisationID != null)
            {
                setData = true;
                @organisation = await _context.Organisation
                .Where(organistionID =>
                _context.Organisation.Any(x => x.OrganisationID == organisationSearch.OrganisationID)).ToListAsync();
            }

            if (!setData)
            {
                if (organisationSearch.CategoryID != null)
                {
                    @organisation = await _context.Organisation
                    .Where(organistionID =>
                    _context.Organisation_Category.Any(y => y.CategoryID == organisationSearch.CategoryID && y.OrganisationID == organistionID.OrganisationID)).ToListAsync();
                    setData = true;
                }

            }
            else
            {
                if (organisationSearch.CategoryID != null)
                    @organisation = @organisation.Where(organistionID => _context.Organisation_Category.Any(y => y.CategoryID == organisationSearch.CategoryID && y.OrganisationID == organistionID.OrganisationID)).ToList();
            }
            //7
            if (!setData)
            {
                if (organisationSearch.Publish != null)
                {
                    @organisation = await _context.Organisation
                    .Where(organistionID => organisationSearch.Publish == organistionID.Publish).ToListAsync();
                    setData = true;
                }
            }
            else
            {
                if (organisationSearch.Publish != null)
                    @organisation = @organisation.Where(organistionID => organisationSearch.Publish == organistionID.Publish).ToList();
            }

            //8
            if (!setData)
            {
                if (organisationSearch.Active != null)
                {
                    @organisation = await _context.Organisation
                    .Where(organistionID => organisationSearch.Active == organistionID.Active).ToListAsync();
                    setData = true;
                }
            }
            else
            {
                if (organisationSearch.Active != null)
                    @organisation = @organisation.Where(organistionID => organisationSearch.Active == organistionID.Active).ToList();
            }

            if (@organisation == null)
            {
                return NotFound();
            }

            return @organisation;
        }


        // PUT: api/Organisations/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutOrganisation(Organisation organisation)
        {
            //if (id != organisation.OrganisationID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(organisation).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OrganisationExists(Convert.ToInt32(organisation.OrganisationID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Organisations
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<Organisation>> PostOrganisation(Organisation organisation)
        {
            _context.Organisation.Add(organisation);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetOrganisation", new { id = organisation.OrganisationID }, organisation);
        }

        // DELETE: api/Organisations/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Organisation>> DeleteOrganisation(int? id)
        {
            var organisation = await _context.Organisation.FindAsync(id);
            if (organisation == null)
            {
                return NotFound();
            }

            _context.Organisation.Remove(organisation);
            await _context.SaveChangesAsync();

            return organisation;
        }

        private bool OrganisationExists(int? id)
        {
            return _context.Organisation.Any(e => e.OrganisationID == id);
        }


        [HttpPost]
        [Route("SaveMultipleOrganisations")]
        public async Task<ActionResult<IEnumerable<Organisation>>> SaveMultipleOrganisations(List<Organisation> @organisations)
        {
            _context.Organisation.AddRange(@organisations);
            await _context.SaveChangesAsync();

            return NoContent();
        }

    }
}
