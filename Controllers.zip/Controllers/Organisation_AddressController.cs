﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Organisation_AddressController : ControllerBase
    {
        private readonly NewDBContext _context;

        public Organisation_AddressController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/Organisation_Address
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Organisation_Address>>> GetOrganisation_Address()
        {
            return await _context.Organisation_Address.ToListAsync();
        }

        // GET: api/Organisation_Address/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Organisation_Address>> GetOrganisation_Address(int? id)
        {
            var organisation_Address = await _context.Organisation_Address.FindAsync(id);

            if (organisation_Address == null)
            {
                return NotFound();
            }

            return organisation_Address;
        }

        // PUT: api/Organisation_Address/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutOrganisation_Address(Organisation_Address organisation_Address)
        {
            //if (id != organisation_Address.Organisation_AddressID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(organisation_Address).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Organisation_AddressExists(Convert.ToInt32(organisation_Address.Organisation_AddressID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Organisation_Address
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<Organisation_Address>> PostOrganisation_Address(Organisation_Address organisation_Address)
        {
            _context.Organisation_Address.Add(organisation_Address);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetOrganisation_Address", new { id = organisation_Address.Organisation_AddressID }, organisation_Address);
        }

        // DELETE: api/Organisation_Address/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Organisation_Address>> DeleteOrganisation_Address(int? id)
        {
            var organisation_Address = await _context.Organisation_Address.FindAsync(id);
            if (organisation_Address == null)
            {
                return NotFound();
            }

            _context.Organisation_Address.Remove(organisation_Address);
            await _context.SaveChangesAsync();

            return organisation_Address;
        }

        private bool Organisation_AddressExists(int? id)
        {
            return _context.Organisation_Address.Any(e => e.Organisation_AddressID == id);
        }
    }
}
