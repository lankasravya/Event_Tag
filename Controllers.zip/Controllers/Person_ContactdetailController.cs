﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Person_ContactdetailController : ControllerBase
    {
        private readonly NewDBContext _context;

        public Person_ContactdetailController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/Person_Contactdetail
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Person_Contactdetail>>> GetPerson_Contactdetail()
        {
            return await _context.Person_Contactdetail.ToListAsync();
        }

        // GET: api/Person_Contactdetail/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Person_Contactdetail>> GetPerson_Contactdetail(int? id)
        {
            var person_Contactdetail = await _context.Person_Contactdetail.FindAsync(id);

            if (person_Contactdetail == null)
            {
                return NotFound();
            }

            return person_Contactdetail;
        }

        // PUT: api/Person_Contactdetail/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutPerson_Contactdetail(Person_Contactdetail person_Contactdetail)
        {
            //if (id != person_Contactdetail.Person_ContactDetailID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(person_Contactdetail).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Person_ContactdetailExists(Convert.ToInt32(person_Contactdetail.Person_ContactDetailID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Person_Contactdetail
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<Person_Contactdetail>> PostPerson_Contactdetail(Person_Contactdetail person_Contactdetail)
        {
            _context.Person_Contactdetail.Add(person_Contactdetail);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetPerson_Contactdetail", new { id = person_Contactdetail.Person_ContactDetailID }, person_Contactdetail);
        }

        // DELETE: api/Person_Contactdetail/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Person_Contactdetail>> DeletePerson_Contactdetail(int? id)
        {
            var person_Contactdetail = await _context.Person_Contactdetail.FindAsync(id);
            if (person_Contactdetail == null)
            {
                return NotFound();
            }

            _context.Person_Contactdetail.Remove(person_Contactdetail);
            await _context.SaveChangesAsync();

            return person_Contactdetail;
        }

        private bool Person_ContactdetailExists(int? id)
        {
            return _context.Person_Contactdetail.Any(e => e.Person_ContactDetailID == id);
        }
    }
}
