﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Organisation_PersonController : ControllerBase
    {
        private readonly NewDBContext _context;

        public Organisation_PersonController(NewDBContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        // GET: api/Organisation_Person
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Organisation_Person>>> GetOrganisation_Person()
        {
            return await _context.Organisation_Person.ToListAsync();
        }

        // GET: api/Organisation_Person/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Organisation_Person>> GetOrganisation_Person(int? id)
        {
            var organisation_Person = await _context.Organisation_Person.FindAsync(id);

            if (organisation_Person == null)
            {
                return NotFound();
            }

            return organisation_Person;
        }

        // PUT: api/Organisation_Person/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutOrganisation_Person(Organisation_Person organisation_Person)
        {
            //if (id != organisation_Person.Organisation_PersonID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(organisation_Person).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Organisation_PersonExists(Convert.ToInt32(organisation_Person.Organisation_PersonID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Organisation_Person
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<Organisation_Person>> PostOrganisation_Person(Organisation_Person organisation_Person)
        {
            _context.Organisation_Person.Add(organisation_Person);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetOrganisation_Person", new { id = organisation_Person.Organisation_PersonID }, organisation_Person);
        }

        // DELETE: api/Organisation_Person/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Organisation_Person>> DeleteOrganisation_Person(int? id)
        {
            var organisation_Person = await _context.Organisation_Person.FindAsync(id);
            if (organisation_Person == null)
            {
                return NotFound();
            }

            _context.Organisation_Person.Remove(organisation_Person);
            await _context.SaveChangesAsync();

            return organisation_Person;
        }

        private bool Organisation_PersonExists(int? id)
        {
            return _context.Organisation_Person.Any(e => e.Organisation_PersonID == id);
        }
    }
}
