﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventEdition_GenreController : ControllerBase
    {
        private readonly NewDBContext _context;

        public EventEdition_GenreController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/EventEdition_Genre
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EventEdition_Genre>>> GetEventEdition_Genre()
        {
            return await _context.EventEdition_Genre.Include("EventEdition").Include("Genre").ToListAsync();
        }

        // GET: api/EventEdition_Genre/5
        [HttpGet("{id}")]
        public async Task<ActionResult<EventEdition_Genre>> GetEventEdition_Genre(int id)
        {
            await _context.EventEdition_Genre.Include("EventEdition").Include("Genre").ToListAsync();
            var eventEdition_Genre = await _context.EventEdition_Genre.FindAsync(id);

            if (eventEdition_Genre == null)
            {
                return NotFound();
            }

            return eventEdition_Genre;
        }

        // PUT: api/EventEdition_Genre/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutEventEdition_Genre(EventEdition_Genre eventEdition_Genre)
        {
            //if (id != eventEdition_Genre.EventEdition_GenreID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(eventEdition_Genre).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EventEdition_GenreExists(Convert.ToInt32(eventEdition_Genre.EventEdition_GenreID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/EventEdition_Genre
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        //[HttpPost]
        //public async Task<ActionResult<EventEdition_Genre>> PostEventEdition_Genre(EventEdition_Genre eventEdition_Genre)
        //{
        //    _context.EventEdition_Genre.Add(eventEdition_Genre);
        //    await _context.SaveChangesAsync();

        //    return CreatedAtAction("GetEventEdition_Genre", new { id = eventEdition_Genre.EventEdition_GenreID }, eventEdition_Genre);
        //}

        [HttpPost]
        public async Task<ActionResult<IEnumerable<EventEdition_Genre>>> PostEventEdition_Genre(EventEdition_Genre eventEdition_Genre)
        {
            _context.EventEdition_Genre.Add(eventEdition_Genre);
            await _context.SaveChangesAsync();

            CreatedAtAction("GetEventEdition_Genre", new { id = eventEdition_Genre.EventEdition_GenreID }, eventEdition_Genre);
            return await _context.EventEdition_Genre.Where(x => x.EventEditionID == eventEdition_Genre.EventEditionID).ToListAsync();
        }

        // DELETE: api/EventEdition_Genre/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<EventEdition_Genre>> DeleteEventEdition_Genre(int id)
        {
            var eventEdition_Genre = await _context.EventEdition_Genre.FindAsync(id);
            if (eventEdition_Genre == null)
            {
                return NotFound();
            }

            _context.EventEdition_Genre.Remove(eventEdition_Genre);
            await _context.SaveChangesAsync();

            return eventEdition_Genre;
        }

        private bool EventEdition_GenreExists(int id)
        {
            return _context.EventEdition_Genre.Any(e => e.EventEdition_GenreID == id);
        }
    }
}
