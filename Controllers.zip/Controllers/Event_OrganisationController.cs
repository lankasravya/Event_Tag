﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Event_OrganisationController : ControllerBase
    {
        private readonly NewDBContext _context;

        public Event_OrganisationController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/Event_Organisation
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Event_Organisation>>> GetEvent_Organisation()
        {
            return await _context.Event_Organisation.Include("Event").ToListAsync();
        }

        // GET: api/Event_Organisation/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Event_Organisation>> GetEvent_Organisation(int id)
        {
            await _context.Event_Organisation.Include("Event").ToListAsync();
            var event_Organisation = await _context.Event_Organisation.FindAsync(id);

            if (event_Organisation == null)
            {
                return NotFound();
            }

            return event_Organisation;
        }

        // PUT: api/Event_Organisation/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutEvent_Organisation(Event_Organisation event_Organisation)
        {
            //if (id != event_Organisation.Event_OrganisationID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(event_Organisation).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Event_OrganisationExists(Convert.ToInt32(event_Organisation.Event_OrganisationID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Event_Organisation
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<Event_Organisation>> PostEvent_Organisation(Event_Organisation event_Organisation)
        {
            _context.Event_Organisation.Add(event_Organisation);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetEvent_Organisation", new { id = event_Organisation.Event_OrganisationID }, event_Organisation);
        }

        // DELETE: api/Event_Organisation/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Event_Organisation>> DeleteEvent_Organisation(int id)
        {
            var event_Organisation = await _context.Event_Organisation.FindAsync(id);
            if (event_Organisation == null)
            {
                return NotFound();
            }

            _context.Event_Organisation.Remove(event_Organisation);
            await _context.SaveChangesAsync();

            return event_Organisation;
        }

        private bool Event_OrganisationExists(int id)
        {
            return _context.Event_Organisation.Any(e => e.Event_OrganisationID == id);
        }
    }
}
