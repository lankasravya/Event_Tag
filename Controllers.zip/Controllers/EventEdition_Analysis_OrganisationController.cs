﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventEdition_Analysis_OrganisationController : ControllerBase
    {
        private readonly NewDBContext _context;

        public EventEdition_Analysis_OrganisationController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/EventEdition_Analysis_Organisation
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EventEdition_Analysis_Organisation>>> GetEventEdition_Analysis_Organisation()
        {
            return await _context.EventEdition_Analysis_Organisation.Include("EventType_AnalysisID").ToListAsync();
        }

        // GET: api/EventEdition_Analysis_Organisation/5
        [HttpGet("{id}")]
        public async Task<ActionResult<EventEdition_Analysis_Organisation>> GetEventEdition_Analysis_Organisation(int id)
        {
            await _context.EventEdition_Analysis_Organisation.Include("EventType_AnalysisID").ToListAsync();
            var eventEdition_Analysis_Organisation = await _context.EventEdition_Analysis_Organisation.FindAsync(id);

            if (eventEdition_Analysis_Organisation == null)
            {
                return NotFound();
            }

            return eventEdition_Analysis_Organisation;
        }

        // PUT: api/EventEdition_Analysis_Organisation/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutEventEdition_Analysis_Organisation(EventEdition_Analysis_Organisation eventEdition_Analysis_Organisation)
        {
            //if (id != eventEdition_Analysis_Organisation.EventType_Analysis_OrganisationID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(eventEdition_Analysis_Organisation).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EventEdition_Analysis_OrganisationExists(Convert.ToInt32(eventEdition_Analysis_Organisation.EventType_Analysis_OrganisationID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/EventEdition_Analysis_Organisation
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<EventEdition_Analysis_Organisation>> PostEventEdition_Analysis_Organisation(EventEdition_Analysis_Organisation eventEdition_Analysis_Organisation)
        {
            _context.EventEdition_Analysis_Organisation.Add(eventEdition_Analysis_Organisation);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetEventEdition_Analysis_Organisation", new { id = eventEdition_Analysis_Organisation.EventType_Analysis_OrganisationID }, eventEdition_Analysis_Organisation);
        }

        // DELETE: api/EventEdition_Analysis_Organisation/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<EventEdition_Analysis_Organisation>> DeleteEventEdition_Analysis_Organisation(int id)
        {
            var eventEdition_Analysis_Organisation = await _context.EventEdition_Analysis_Organisation.FindAsync(id);
            if (eventEdition_Analysis_Organisation == null)
            {
                return NotFound();
            }

            _context.EventEdition_Analysis_Organisation.Remove(eventEdition_Analysis_Organisation);
            await _context.SaveChangesAsync();

            return eventEdition_Analysis_Organisation;
        }

        private bool EventEdition_Analysis_OrganisationExists(int id)
        {
            return _context.EventEdition_Analysis_Organisation.Any(e => e.EventType_Analysis_OrganisationID == id);
        }
    }
}
