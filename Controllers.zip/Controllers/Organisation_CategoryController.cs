﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Organisation_CategoryController : ControllerBase
    {
        private readonly NewDBContext _context;

        public Organisation_CategoryController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/Organisation_Category
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Organisation_Category>>> GetOrganisation_Category()
        {
            return await _context.Organisation_Category.ToListAsync();
        }

        // GET: api/Organisation_Category/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Organisation_Category>> GetOrganisation_Category(int? id)
        {
            var organisation_Category = await _context.Organisation_Category.FindAsync(id);

            if (organisation_Category == null)
            {
                return NotFound();
            }

            return organisation_Category;
        }

        // PUT: api/Organisation_Category/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutOrganisation_Category(Organisation_Category organisation_Category)
        {
            //if (id != organisation_Category.Organisation_CategoryID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(organisation_Category).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Organisation_CategoryExists(Convert.ToInt32(organisation_Category.Organisation_CategoryID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Organisation_Category
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<Organisation_Category>> PostOrganisation_Category(Organisation_Category organisation_Category)
        {
            _context.Organisation_Category.Add(organisation_Category);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetOrganisation_Category", new { id = organisation_Category.Organisation_CategoryID }, organisation_Category);
        }

        // DELETE: api/Organisation_Category/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Organisation_Category>> DeleteOrganisation_Category(int? id)
        {
            var organisation_Category = await _context.Organisation_Category.FindAsync(id);
            if (organisation_Category == null)
            {
                return NotFound();
            }

            _context.Organisation_Category.Remove(organisation_Category);
            await _context.SaveChangesAsync();

            return organisation_Category;
        }

        private bool Organisation_CategoryExists(int? id)
        {
            return _context.Organisation_Category.Any(e => e.Organisation_CategoryID == id);
        }
    }
}
