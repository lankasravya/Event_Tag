﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventEdition_CategoryController : ControllerBase
    {
        private readonly NewDBContext _context;

        public EventEdition_CategoryController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/EventEdition_Category
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EventEdition_Category>>> GetEventEdition_Category()
        {
            return await _context.EventEdition_Category.Include("Category").Include("EventEdition").ToListAsync();
        }

        // GET: api/EventEdition_Category/5
        [HttpGet("{id}")]
        public async Task<ActionResult<IEnumerable<EventEdition_Category>>> GetEventEdition_Category(int? id)
        {
            var eventEdition_Category = await _context.EventEdition_Category.Include("Category").Include("EventEdition").Where(i => i.EventEditionID == id).ToListAsync();

            if (eventEdition_Category == null)
            {
                return NotFound();
            }

            return eventEdition_Category;
        }

        // PUT: api/EventEdition_Category/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutEventEdition_Category(EventEdition_Category eventEdition_Category)
        {
            //if (id != eventEdition_Category.EventEdition_CategoryID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(eventEdition_Category).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EventEdition_CategoryExists(Convert.ToInt32(eventEdition_Category.EventEdition_CategoryID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/EventEdition_Category
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<EventEdition_Category>> PostEventEdition_Category(EventEdition_Category eventEdition_Category)
        {
            _context.EventEdition_Category.Add(eventEdition_Category);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetEventEdition_Category", new { id = eventEdition_Category.EventEdition_CategoryID }, eventEdition_Category);
        }

        // DELETE: api/EventEdition_Category/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<EventEdition_Category>> DeleteEventEdition_Category(int? id)
        {
            var eventEdition_Category = await _context.EventEdition_Category.FindAsync(id);
            if (eventEdition_Category == null)
            {
                return NotFound();
            }

            _context.EventEdition_Category.Remove(eventEdition_Category);
            await _context.SaveChangesAsync();

            return eventEdition_Category;
        }

        private bool EventEdition_CategoryExists(int? id)
        {
            return _context.EventEdition_Category.Any(e => e.EventEdition_CategoryID == id);
        }
    }
}
