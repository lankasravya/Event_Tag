﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Organisation_ContactdetailController : ControllerBase
    {
        private readonly NewDBContext _context;

        public Organisation_ContactdetailController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/Organisation_Contactdetail
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Organisation_Contactdetail>>> GetOrganisation_Contactdetail()
        {
            return await _context.Organisation_Contactdetail.ToListAsync();
        }

        // GET: api/Organisation_Contactdetail/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Organisation_Contactdetail>> GetOrganisation_Contactdetail(int? id)
        {
            var organisation_Contactdetail = await _context.Organisation_Contactdetail.FindAsync(id);

            if (organisation_Contactdetail == null)
            {
                return NotFound();
            }

            return organisation_Contactdetail;
        }

        // PUT: api/Organisation_Contactdetail/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutOrganisation_Contactdetail(Organisation_Contactdetail organisation_Contactdetail)
        {
            //if (id != organisation_Contactdetail.Organisation_ContactDetailID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(organisation_Contactdetail).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Organisation_ContactdetailExists(Convert.ToInt32(organisation_Contactdetail.Organisation_ContactDetailID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Organisation_Contactdetail
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<Organisation_Contactdetail>> PostOrganisation_Contactdetail(Organisation_Contactdetail organisation_Contactdetail)
        {
            _context.Organisation_Contactdetail.Add(organisation_Contactdetail);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetOrganisation_Contactdetail", new { id = organisation_Contactdetail.Organisation_ContactDetailID }, organisation_Contactdetail);
        }

        // DELETE: api/Organisation_Contactdetail/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Organisation_Contactdetail>> DeleteOrganisation_Contactdetail(int? id)
        {
            var organisation_Contactdetail = await _context.Organisation_Contactdetail.FindAsync(id);
            if (organisation_Contactdetail == null)
            {
                return NotFound();
            }

            _context.Organisation_Contactdetail.Remove(organisation_Contactdetail);
            await _context.SaveChangesAsync();

            return organisation_Contactdetail;
        }

        private bool Organisation_ContactdetailExists(int? id)
        {
            return _context.Organisation_Contactdetail.Any(e => e.Organisation_ContactDetailID == id);
        }
    }
}
