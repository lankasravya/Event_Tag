﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Person_AddressController : ControllerBase
    {
        private readonly NewDBContext _context;

        public Person_AddressController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/Person_Address
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Person_Address>>> GetPerson_Address()
        {
            return await _context.Person_Address.ToListAsync();
        }

        // GET: api/Person_Address/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Person_Address>> GetPerson_Address(int? id)
        {
            var person_Address = await _context.Person_Address.FindAsync(id);

            if (person_Address == null)
            {
                return NotFound();
            }

            return person_Address;
        }

        // PUT: api/Person_Address/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutPerson_Address(Person_Address person_Address)
        {
            //if (id != person_Address.Person_AddressID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(person_Address).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Person_AddressExists(Convert.ToInt32(person_Address.Person_AddressID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Person_Address
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<Person_Address>> PostPerson_Address(Person_Address person_Address)
        {
            _context.Person_Address.Add(person_Address);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetPerson_Address", new { id = person_Address.Person_AddressID }, person_Address);
        }

        // DELETE: api/Person_Address/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Person_Address>> DeletePerson_Address(int? id)
        {
            var person_Address = await _context.Person_Address.FindAsync(id);
            if (person_Address == null)
            {
                return NotFound();
            }

            _context.Person_Address.Remove(person_Address);
            await _context.SaveChangesAsync();

            return person_Address;
        }

        private bool Person_AddressExists(int? id)
        {
            return _context.Person_Address.Any(e => e.Person_AddressID == id);
        }
    }
}
