﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Event_CategoryController : ControllerBase
    {
        private readonly NewDBContext _context;

        public Event_CategoryController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/Event_Category
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Event_Category>>> GetEvent_Category()
        {
            return await _context.Event_Category.Include("Category").Include("Event").ToListAsync();
        }

        // GET: api/Event_Category/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Event_Category>> GetEvent_Category(int id)
        {
            await _context.Event_Category.Include("Event").Include("Category").ToListAsync();
            var event_Category = await _context.Event_Category.FindAsync(id);

            if (event_Category == null)
            {
                return NotFound();
            }

            return event_Category;
        }

        [HttpGet]
        [Route("GetEvent_CategoryByEventID/{eventId}")]
        public async Task<ActionResult<IEnumerable<Event_Category>>> GetEventCategoryByEventId(int? eventId)
        {
            
            if (eventId !=null)
            {

                var Event_Category = await _context.Event_Category.Include("Category").Include("Event").Where(x => x.EventID == eventId).ToListAsync();
                return Event_Category;
            }

            else
                return null;
        }

        // PUT: api/Event_Category/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutEvent_Category(Event_Category event_Category)
        {
            //if (id != event_Category.Event_CategoryID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(event_Category).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Event_CategoryExists(Convert.ToInt32(event_Category.Event_CategoryID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Event_Category
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        //[HttpPost]
        //public async Task<ActionResult<Event_Category>> PostEvent_Category(Event_Category event_Category)
        //{
        //    _context.Event_Category.Add(event_Category);
        //    await _context.SaveChangesAsync();

        //    return CreatedAtAction("GetEvent_Category", new { id = event_Category.Event_CategoryID }, event_Category);
        //}

        [HttpPost]
        public async Task<ActionResult<IEnumerable<Event_Category>>> PostEvent_Category(Event_Category event_Category)
        {
            _context.Event_Category.Add(event_Category);
            await _context.SaveChangesAsync();

            CreatedAtAction("GetEvent_Category", new { id = event_Category.Event_CategoryID }, event_Category);
            return await _context.Event_Category.Where(x => x.EventID == event_Category.EventID).ToListAsync();
        }

        // DELETE: api/Event_Category/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Event_Category>> DeleteEvent_Category(int id)
        {
            var event_Category = await _context.Event_Category.FindAsync(id);
            if (event_Category == null)
            {
                return NotFound();
            }

            _context.Event_Category.Remove(event_Category);
            await _context.SaveChangesAsync();

            return event_Category;
        }

        private bool Event_CategoryExists(int id)
        {
            return _context.Event_Category.Any(e => e.Event_CategoryID == id);
        }
    }
}
