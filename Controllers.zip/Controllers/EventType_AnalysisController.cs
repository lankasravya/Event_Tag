﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventType_AnalysisController : ControllerBase
    {
        private readonly NewDBContext _context;

        public EventType_AnalysisController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/EventType_Analysis
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EventType_Analysis>>> GetEventType_Analysis()
        {
            return await _context.EventType_Analysis.Include("Analysis").ToListAsync();
        }

        // GET: api/EventType_Analysis/5
        [HttpGet("{id}")]
        public async Task<ActionResult<EventType_Analysis>> GetEventType_Analysis(int id)
        {
            await _context.EventType_Analysis.Include("Analysis").ToListAsync();
            var eventType_Analysis = await _context.EventType_Analysis.FindAsync(id);

            if (eventType_Analysis == null)
            {
                return NotFound();
            }

            return eventType_Analysis;
        }

        // PUT: api/EventType_Analysis/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutEventType_Analysis(EventType_Analysis eventType_Analysis)
        {
            //if (id != eventType_Analysis.EventType_AnalysisID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(eventType_Analysis).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EventType_AnalysisExists(Convert.ToInt32(eventType_Analysis.EventType_AnalysisID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/EventType_Analysis
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<EventType_Analysis>> PostEventType_Analysis(EventType_Analysis eventType_Analysis)
        {
            _context.EventType_Analysis.Add(eventType_Analysis);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetEventType_Analysis", new { id = eventType_Analysis.EventType_AnalysisID }, eventType_Analysis);
        }

        // DELETE: api/EventType_Analysis/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<EventType_Analysis>> DeleteEventType_Analysis(int id)
        {
            var eventType_Analysis = await _context.EventType_Analysis.FindAsync(id);
            if (eventType_Analysis == null)
            {
                return NotFound();
            }

            _context.EventType_Analysis.Remove(eventType_Analysis);
            await _context.SaveChangesAsync();

            return eventType_Analysis;
        }

        private bool EventType_AnalysisExists(int id)
        {
            return _context.EventType_Analysis.Any(e => e.EventType_AnalysisID == id);
        }
    }
}
