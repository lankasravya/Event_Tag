﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventEdition_LocationController : ControllerBase
    {
        private readonly NewDBContext _context;

        public EventEdition_LocationController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/EventEdition_Location
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EventEdition_Location>>> GetEventEdition_Location()
        {
            return await _context.EventEdition_Location.Include("Location").Include("EventEdition").ToListAsync();
        }

        // GET: api/EventEdition_Location/5
        [HttpGet("{id}")]
        
        public async Task<ActionResult<EventEdition_Location>> GetEventEdition_Location(int id)
        {

            await _context.EventEdition_Location.Include("Location").Include("EventEdition").ToListAsync();
            var eventEdition_Location = await _context.EventEdition_Location.FindAsync(id);

            if (eventEdition_Location == null)
            {
                return NotFound();
            }

            return eventEdition_Location;
        }

        [HttpGet]
        [Route("GetEventEditionLocationByEventEditionID/{eventEditionId}")]
        public async Task<ActionResult<IEnumerable<EventEdition_Location>>> GetEventEdition_Location(int? eventEditionId)
        {
           // var eventEdition_Location =await _context.EventEdition_Location.FindAsync(eventEdition);
            if (eventEditionId != null)
            {

                var eventEdition_Location = await _context.EventEdition_Location.Include("Location").Include("EventEdition").Where(x => x.EventEditionID == eventEditionId).ToListAsync();
                return eventEdition_Location;
            }

            else
                return null;
        }


        // PUT: api/EventEdition_Location/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutEventEdition_Location(EventEdition_Location eventEdition_Location)
        {
            //if (id != eventEdition_Location.EventEdition_LocationID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(eventEdition_Location).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EventEdition_LocationExists(Convert.ToInt32(eventEdition_Location.EventEdition_LocationID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/EventEdition_Location
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        //[HttpPost]
        //public async Task<ActionResult<EventEdition_Location>> PostEventEdition_Location(EventEdition_Location eventEdition_Location)
        //{
        //    _context.EventEdition_Location.Add(eventEdition_Location);
        //    await _context.SaveChangesAsync();

        //    return CreatedAtAction("GetEventEdition_Location", new { id = eventEdition_Location.EventEdition_LocationID }, eventEdition_Location);
        //}

        [HttpPost]
        public async Task<ActionResult<IEnumerable<EventEdition_Location>>> PostEventEdition_Location(EventEdition_Location eventEdition_Location)
        {
            _context.EventEdition_Location.Add(eventEdition_Location);
            await _context.SaveChangesAsync();

            CreatedAtAction("GetEventEdition_Location", new { id = eventEdition_Location.EventEdition_LocationID }, eventEdition_Location);
            return await _context.EventEdition_Location.Where(x => x.EventEditionID == eventEdition_Location.EventEditionID).ToListAsync();
        }

        // DELETE: api/EventEdition_Location/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<EventEdition_Location>> DeleteEventEdition_Location(int id)
        {
            var eventEdition_Location = await _context.EventEdition_Location.FindAsync(id);
            if (eventEdition_Location == null)
            {
                return NotFound();
            }

            _context.EventEdition_Location.Remove(eventEdition_Location);
            await _context.SaveChangesAsync();

            return eventEdition_Location;
        }

        private bool EventEdition_LocationExists(int id)
        {
            return _context.EventEdition_Location.Any(e => e.EventEdition_LocationID == id);
        }
    }
}
