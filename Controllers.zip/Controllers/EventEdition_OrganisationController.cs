﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventEdition_OrganisationController : ControllerBase
    {
        private readonly NewDBContext _context;

        public EventEdition_OrganisationController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/EventEdition_Organisation
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EventEdition_Organisation>>> GetEventEdition_Organisation()
        {
            return await _context.EventEdition_Organisation.Include("EventEdition").ToListAsync();
        }

        // GET: api/EventEdition_Organisation/5
        [HttpGet("{id}")]
        public async Task<ActionResult<EventEdition_Organisation>> GetEventEdition_Organisation(int id)
        {
            await _context.EventEdition_Organisation.Include("EventEdition").ToListAsync();
            var eventEdition_Organisation = await _context.EventEdition_Organisation.FindAsync(id);

            if (eventEdition_Organisation == null)
            {
                return NotFound();
            }

            return eventEdition_Organisation;
        }

        [HttpPost]
        [Route("GetEventEditionOrganisersByEventEditionID/{eventEditionId}")]
        public async Task<ActionResult<IEnumerable<EventEdition_Organisation>>> GetEventEditionOrganisation(int eventEditionId)
        {
            // var eventEdition_Location =await _context.EventEdition_Location.FindAsync(eventEdition);
            if (eventEditionId != null)
            {

                var EventEdition_Organisation = await _context.EventEdition_Organisation.Where(x => x.EventEditionID == eventEditionId).ToListAsync();
                return EventEdition_Organisation;
            }

            else
                return null;
        }

        // PUT: api/EventEdition_Organisation/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutEventEdition_Organisation(EventEdition_Organisation eventEdition_Organisation)
        {
            //if (id != eventEdition_Organisation.EventEdition_OrganisationID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(eventEdition_Organisation).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EventEdition_OrganisationExists(Convert.ToInt32(eventEdition_Organisation.EventEdition_OrganisationID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/EventEdition_Organisation
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        //[HttpPost]
        //public async Task<ActionResult<EventEdition_Organisation>> PostEventEdition_Organisation(EventEdition_Organisation eventEdition_Organisation)
        //{
        //    _context.EventEdition_Organisation.Add(eventEdition_Organisation);
        //    await _context.SaveChangesAsync();

        //    return CreatedAtAction("GetEventEdition_Organisation", new { id = eventEdition_Organisation.EventEdition_OrganisationID }, eventEdition_Organisation);
        //}

        [HttpPost]
        public async Task<ActionResult<IEnumerable<EventEdition_Organisation>>> PostEventEdition_Organisation(EventEdition_Organisation eventEdition_Organisation)
        {
            _context.EventEdition_Organisation.Add(eventEdition_Organisation);
            await _context.SaveChangesAsync();

            CreatedAtAction("GetEventEdition_Organisation", new { id = eventEdition_Organisation.EventEdition_OrganisationID }, eventEdition_Organisation);
            return await _context.EventEdition_Organisation.Where(x => x.EventEditionID == eventEdition_Organisation.EventEditionID).ToListAsync();
        }

        // DELETE: api/EventEdition_Organisation/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<EventEdition_Organisation>> DeleteEventEdition_Organisation(int id)
        {
            var eventEdition_Organisation = await _context.EventEdition_Organisation.FindAsync(id);
            if (eventEdition_Organisation == null)
            {
                return NotFound();
            }

            _context.EventEdition_Organisation.Remove(eventEdition_Organisation);
            await _context.SaveChangesAsync();

            return eventEdition_Organisation;
        }

        private bool EventEdition_OrganisationExists(int id)
        {
            return _context.EventEdition_Organisation.Any(e => e.EventEdition_OrganisationID == id);
        }
    }
}
