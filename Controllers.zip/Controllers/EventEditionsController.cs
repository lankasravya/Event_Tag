﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Search;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventEditionsController : ControllerBase
    {
        private readonly NewDBContext _context;

        public EventEditionsController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/EventEditions
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EventEdition>>> GetEventEdition()
        {
            return await _context.EventEdition.Include("Event").ToListAsync();
        }

        // GET: api/EventEditions/5
        [HttpGet("{id}")]
        public async Task<ActionResult<EventEdition>> GetEventEdition(int id)
        {
            await _context.EventEdition.Include("Event").ToListAsync();
            var eventEdition = await _context.EventEdition.FindAsync(id);

            if (eventEdition == null)
            {
                return NotFound();
            }

            return eventEdition;
        }

        // PUT: api/EventEditions/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutEventEdition(EventEdition eventEdition)
        {
            //if (id != eventEdition.EventEditionID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(eventEdition).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EventEditionExists(Convert.ToInt32(eventEdition.EventEditionID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/EventEditions
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<EventEdition>> PostEventEdition(EventEdition eventEdition)
        {
            _context.EventEdition.Add(eventEdition);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetEventEdition", new { id = eventEdition.EventEditionID }, eventEdition);
        }

        [HttpPost]
        [Route("PostMultipleEventEditions")]
        public async Task<ActionResult<IEnumerable<EventEdition>>> PostMultipleEventEdition(List<EventEdition> eventEditions)
        {
            _context.EventEdition.AddRange(eventEditions);
            await _context.SaveChangesAsync();
            //return CreatedAtAction("GetEventEdition", new { id = eventEdition.EventEditionID }, eventEdition);
            return eventEditions;
        }


        // DELETE: api/EventEditions/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<EventEdition>> DeleteEventEdition(int id)
        {
            var eventEdition = await _context.EventEdition.FindAsync(id);
            if (eventEdition == null)
            {
                return NotFound();
            }

            _context.EventEdition.Remove(eventEdition);
            await _context.SaveChangesAsync();

            return eventEdition;
        }

        private bool EventEditionExists(int id)
        {
            return _context.EventEdition.Any(e => e.EventEditionID == id);
        }

        [HttpPost]
        [Route("EventEditionSearch")]
        public async Task<ActionResult<IEnumerable<EventEdition>>> GetEvent(EventEditionSearch eventSearch)
        {
            List<EventEdition> @event = new List<EventEdition>();
            bool setData = false;
            if (eventSearch.GenreId != null)
            {
                setData = true;
                @event = await _context.EventEdition
                .Where(eventId =>
                _context.Event_Genre.Any(x => x.GenreID == eventSearch.GenreId && x.EventID == eventId.EventID)).ToListAsync();
            }

            if (!setData)
            {
                if (eventSearch.EventName != null)
                {
                    @event = await _context.EventEdition.Include("Event")
                    .Where(eventId =>
                    _context.Event.Any(y => y.EventID == eventId.EventID && y.Name == eventSearch.EventName)).ToListAsync();
                    setData = true;
                }
            }
            else
            {
                if (eventSearch.EventName != null)
                    @event = @event.Where(eventId =>
                    _context.Event.Any(y => y.EventID == eventId.EventID && y.Name == eventSearch.EventName)).ToList();
            }

            //3
            if (!setData)
            {
                if (eventSearch.LocationId != null)
                {
                    @event = await _context.EventEdition
                    .Where(eventId =>
                    _context.EventEdition_Location.Any(x => x.LocationID == eventSearch.LocationId && x.EventEditionID == eventId.EventEditionID)).ToListAsync();
                    setData = true;
                }
            }
            else
            {
                if (eventSearch.LocationId != null)
                    @event = @event.Where(eventId =>
                    _context.EventEdition_Location.Any(x => x.LocationID == eventSearch.LocationId && x.EventEditionID == eventId.EventEditionID)).ToList();
            }

            if (!setData)
            {
                if (eventSearch.EventEditionOrganisationId != null)
                {
                    @event = await _context.EventEdition
                    .Where(eventId =>
                    _context.EventEdition_Organisation.Any(x => x.EventEdition_OrganisationID == eventSearch.EventEditionOrganisationId && x.EventEditionID == eventId.EventEditionID)).ToListAsync();
                    setData = true;
                }
            }
            else
            {
                if (eventSearch.LocationId != null)
                    @event = @event.Where(eventId =>
                    _context.EventEdition_Organisation.Any(x => x.EventEdition_OrganisationID == eventSearch.EventEditionOrganisationId && x.EventEditionID == eventId.EventEditionID)).ToList();
            }


            //5
            if (!setData)
            {
                if (eventSearch.StartDate != null)
                {
                    @event = await _context.EventEdition
                    .Where(y => y.StartDate == eventSearch.StartDate).ToListAsync();
                    setData = true;
                }   
            }
            else
            {
                if (eventSearch.StartDate != null)
                    @event = @event.Where(y => y.StartDate == eventSearch.StartDate).ToList();
            }


            //7
            if (!setData)
            {
                if (eventSearch.Publish != null)
                {
                    @event = await _context.EventEdition
                    .Where(eventId => eventSearch.Publish == eventId.Publish).ToListAsync();
                    setData = true;
                }
                    
            }
            else
            {
                if (eventSearch.Publish != null)
                    @event = @event.Where(eventId => eventSearch.Publish == eventId.Publish).ToList();
            }

            //8
            if (!setData)
            {
                if (eventSearch.FinishDate != null)
                {
                    @event = await _context.EventEdition
                    .Where(eventId => eventSearch.FinishDate == eventId.FinishDate).ToListAsync();
                    setData = true;
                }   
            }
            else
            {
                if (eventSearch.FinishDate != null)
                    @event = @event.Where(eventId => eventSearch.FinishDate == eventId.FinishDate).ToList();
            }

            if (@event == null)
            {
                return NotFound();
            }

            return @event;
        }

    }
    
}
