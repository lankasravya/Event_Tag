﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventEditionStatusController : ControllerBase
    {
        private readonly NewDBContext _context;

        public EventEditionStatusController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/EventEditionStatus
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EventEditionStatus>>> GetEventEditionStatus()
        {
            return await _context.EventEditionStatus.Include("EventEdition").ToListAsync();
        }

        // GET: api/EventEditionStatus/5
        [HttpGet("{id}")]
        public async Task<ActionResult<EventEditionStatus>> GetEventEditionStatus(int id)
        {
            await _context.EventEditionStatus.Include("EventEdition").ToListAsync();
            var eventEditionStatus = await _context.EventEditionStatus.FindAsync(id);

            if (eventEditionStatus == null)
            {
                return NotFound();
            }

            return eventEditionStatus;
        }


        [HttpGet]
        [Route("GetEventEditionStatusByEventEditionID/{eventEditionStatusId}")]
        public async Task<ActionResult<IEnumerable<EventEditionStatus>>> GetEventEditionStatus(int? eventEditionStatusId)
        {
            
            if (eventEditionStatusId != null)
            {

                var EventEditionStatus = await _context.EventEditionStatus.Where(x => x.EventEditionID == eventEditionStatusId).ToListAsync();
                return EventEditionStatus;
            }

            else
                return null;
        }

        // PUT: api/EventEditionStatus/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutEventEditionStatus(EventEditionStatus eventEditionStatus)
        {
            //if (id != eventEditionStatus.EventEditionStatusID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(eventEditionStatus).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EventEditionStatusExists(Convert.ToInt32(eventEditionStatus.EventEditionStatusID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/EventEditionStatus
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        //[HttpPost]
        //public async Task<ActionResult<EventEditionStatus>> PostEventEditionStatus(EventEditionStatus eventEditionStatus)
        //{
        //    _context.EventEditionStatus.Add(eventEditionStatus);
        //    await _context.SaveChangesAsync();

        //    return CreatedAtAction("GetEventEditionStatus", new { id = eventEditionStatus.EventEditionStatusID }, eventEditionStatus);
        //}

        [HttpPost]
        public async Task<ActionResult<IEnumerable<EventEditionStatus>>> PostEventEditionStatus(EventEditionStatus eventEditionStatus)
        {
            _context.EventEditionStatus.Add(eventEditionStatus);
            await _context.SaveChangesAsync();

            //CreatedAtAction("GetEventEditionStatus", new { id = eventEditionStatus.EventEditionStatusID }, eventEditionStatus);
            return await _context.EventEditionStatus.Where(x => x.EventEditionID == eventEditionStatus.EventEditionID).ToListAsync();
        }

        // DELETE: api/EventEditionStatus/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<EventEditionStatus>> DeleteEventEditionStatus(int id)
        {
            var eventEditionStatus = await _context.EventEditionStatus.FindAsync(id);
            if (eventEditionStatus == null)
            {
                return NotFound();
            }

            _context.EventEditionStatus.Remove(eventEditionStatus);
            await _context.SaveChangesAsync();

            return eventEditionStatus;
        }

        private bool EventEditionStatusExists(int id)
        {
            return _context.EventEditionStatus.Any(e => e.EventEditionStatusID == id);
        }
    }
}
