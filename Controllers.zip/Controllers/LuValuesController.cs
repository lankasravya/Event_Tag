﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LuValuesController : ControllerBase
    {
        private readonly NewDBContext _context;

        public LuValuesController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/LuValues
        [HttpGet]
        public async Task<ActionResult<IEnumerable<LuValue>>> GetLuValue()
        {
            return await _context.LuValue.Include("LuType").ToListAsync();
        }

        // GET: api/LuValues/5
        [HttpGet("{id}")]
        public async Task<ActionResult<LuValue>> GetLuValue(int id)
        {
            await _context.LuValue.Include("LuType").ToListAsync();
            var luValue = await _context.LuValue.FindAsync(id);

            if (luValue == null)
            {
                return NotFound();
            }

            return luValue;
        }

        // PUT: api/LuValues/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutLuValue(LuValue luValue)
        {
            //if (id != luValue.LuValueID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(luValue).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!LuValueExists(Convert.ToInt32(luValue.LuValueID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/LuValues
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<LuValue>> PostLuValue(LuValue luValue)
        {
            _context.LuValue.Add(luValue);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetLuValue", new { id = luValue.LuValueID }, luValue);
        }

        // DELETE: api/LuValues/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<LuValue>> DeleteLuValue(int id)
        {
            var luValue = await _context.LuValue.FindAsync(id);
            if (luValue == null)
            {
                return NotFound();
            }

            _context.LuValue.Remove(luValue);
            await _context.SaveChangesAsync();

            return luValue;
        }

        private bool LuValueExists(int id)
        {
            return _context.LuValue.Any(e => e.LuValueID == id);
        }
    }
}
