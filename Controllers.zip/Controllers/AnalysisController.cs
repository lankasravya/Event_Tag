﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnalysisController : ControllerBase
    {
        private readonly NewDBContext _context;

        public AnalysisController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/Analysis
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Analysis>>> GetAnalysis()
        {
            return await _context.Analysis.ToListAsync();
        }

        // GET: api/Analysis/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Analysis>> GetAnalysis(int id)
        {
            var analysis = await _context.Analysis.FindAsync(id);

            if (analysis == null)
            {
                return NotFound();
            }

            return analysis;
        }

        // PUT: api/Analysis/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutAnalysis(Analysis analysis)
        {
            //if (id != analysis.AnalysisID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(analysis).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AnalysisExists(Convert.ToInt32(analysis.AnalysisID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Analysis
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<Analysis>> PostAnalysis(Analysis analysis)
        {
            _context.Analysis.Add(analysis);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAnalysis", new { id = analysis.AnalysisID }, analysis);
        }

        // DELETE: api/Analysis/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Analysis>> DeleteAnalysis(int id)
        {
            var analysis = await _context.Analysis.FindAsync(id);
            if (analysis == null)
            {
                return NotFound();
            }

            _context.Analysis.Remove(analysis);
            await _context.SaveChangesAsync();

            return analysis;
        }

        private bool AnalysisExists(int id)
        {
            return _context.Analysis.Any(e => e.AnalysisID == id);
        }
    }
}
