﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Search;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : ControllerBase
    {
        private readonly NewDBContext _context;

        public EventsController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/Events
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Event>>> GetEvent()  
        {
            return await _context.Event.ToListAsync();
        }

        //[GET: api/Events/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Event>> GetEvent(int id)
        {
            var @event = await _context.Event.FindAsync(id);

            if (@event == null)
            {
                return NotFound();
            }

            return @event;
        }

        //[HttpGet("GetBy/{GenreId:int?}/{CategoryId:int?}")]
        [HttpPost]
        [Route("EventSearch")]
        public async Task<ActionResult<IEnumerable<Event>>> GetEvent(EventSearch eventSearch)
        {

            //List<Event> @event = new List<Event>();
            //@event.Add(await _context.Event.Where(x => x.EventID == (await _context.Event_Genre.Where(x => x.GenreID == GenreId).ToListAsync())).ToListAsync());
            //var @event = await _context.Event
            //    .Where(eventId =>
            //    _context.Event_Genre.Any(x => x.GenreID == GenreId && x.EventID == eventId.EventID)
            //    &&
            //     _context.Event_Category.Any(y => y.Event_CategoryID == CategoryId && y.EventID == eventId.EventID)
            //    ).ToListAsync();

            //var @event = _context.Event.Wh
            List<Event> @event = new List<Event>();
            bool setData = false;
            if (eventSearch.GenreID != null)
            {
                setData = true;
                @event = await _context.Event
                .Where(eventId =>
                _context.Event_Genre.Any(x => x.GenreID == eventSearch.GenreID && x.EventID == eventId.EventID)).ToListAsync();
            }

            if (!setData)
            {
                if (eventSearch.CategoryID != null)
                {
                    @event = await _context.Event
                    .Where(eventId =>
                    _context.Event_Category.Any(y => y.Event_CategoryID == eventSearch.CategoryID && y.EventID == eventId.EventID)).ToListAsync();
                    setData = true;
                }

            }
            else
            {
                if (eventSearch.CategoryID != null)
                    @event = @event.Where(eventId => _context.Event_Category.Any(y => y.Event_CategoryID == eventSearch.CategoryID && y.EventID == eventId.EventID)).ToList();
            }

            //3
            if (!setData)
            {
                if (eventSearch.StartYear != null)
                {
                    @event = await _context.Event
                    .Where(eventId =>
                    eventSearch.StartYear == eventId.StartYear).ToListAsync();
                    setData = true;
                }
            }
            else
            {
                if (eventSearch.StartYear != null)
                    @event = @event.Where(eventId => eventSearch.StartYear == eventId.StartYear).ToList();
            }


            //5
            if (!setData)
            {
                if (eventSearch.Name != null)
                {
                    @event = await _context.Event.Where(x => x.Name.Contains(eventSearch.Name)).ToListAsync();
                        //.Where(y => y.Name == eventSearch.Name).ToListAsync();
                    setData = true;
                }

            }
            else
            {
                if (eventSearch.Name != null)
                    @event = @event.Where(y => y.Name == eventSearch.Name).ToList();
            }


            //7
            if (!setData)
            {
                if (eventSearch.Publish != null)
                {
                    @event = await _context.Event
                    .Where(eventId => eventSearch.Publish == eventId.Publish).ToListAsync();
                    setData = true;
                }
            }
            else
            {
                if (eventSearch.Publish != null)
                    @event = @event.Where(eventId => eventSearch.Active == eventId.Active).ToList();
            }

            //8
            if (!setData)
            {
                if (eventSearch.Active != null)
                {
                    @event = await _context.Event
                    .Where(eventId => eventSearch.Active == eventId.Active).ToListAsync();
                    setData = true;
                }
            }
            else
            {
                if (eventSearch.Active != null)
                    @event = @event.Where(eventId => eventSearch.Active == eventId.Active).ToList();
            }

            if (@event == null)
            {
                return NotFound();
            }

            return @event;
        }

        // PUT: api/Events/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutEvent(Event @event)
        {
            //if (id != @event.EventID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(@event).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EventExists(Convert.ToInt32(@event.EventID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Events
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<Event>> PostEvent(Event @event)
        {
            _context.Event.Add(@event);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetEvent", new { id = @event.EventID }, @event);
        }

        [HttpPost]
        [Route("PostMultipleEvents")]
        public async Task<ActionResult<IEnumerable<Event>>> PostMultipleEvent(List<Event> @events)
        {
            _context.Event.AddRange(@events);
            await _context.SaveChangesAsync();

            return @events;
        }

        // DELETE: api/Events/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Event>> DeleteEvent(int id)
        {
            var eventCategory = await _context.Event_Category.Where(x => x.EventID == id).ToListAsync();
            _context.Event_Category.RemoveRange(eventCategory);

            var eventGenre = await _context.Event_Genre.Where(x => x.EventID == id).ToListAsync();
            _context.Event_Genre.RemoveRange(eventGenre);

            var eventOrganization = await _context.Event_Organisation.Where(x => x.EventID == id).ToListAsync();
            _context.Event_Organisation.RemoveRange(eventOrganization);

            var eventEditionGenre = await _context.EventEdition_Genre.Where(y =>
                    _context.EventEdition.Any(x => x.EventID == id && y.EventEditionID == x.EventEditionID)).ToListAsync();

            var eventEditionLocation = await _context.EventEdition_Location.Where(y =>
                    _context.EventEdition.Any(x => x.EventID == id && y.EventEditionID == x.EventEditionID)).ToListAsync();

            var eventEditionOrganization = await _context.EventEdition_Organisation.Where(y =>
                    _context.EventEdition.Any(x => x.EventID == id && y.EventEditionID == x.EventEditionID)).ToListAsync();

            var eventEditionStatus = await _context.EventEditionStatus.Where(y =>
                    _context.EventEdition.Any(x => x.EventID == id && y.EventEditionID == x.EventEditionID)).ToListAsync();



            var eventEdition = await _context.EventEdition.Where(x => x.EventID == id).ToListAsync();
            _context.EventEdition.RemoveRange(eventEdition);








            var @event = await _context.Event.FindAsync(id);

            if (@event == null)
            {
                return NotFound();
            }

            _context.Event.Remove(@event);
            await _context.SaveChangesAsync();

            return @event;
        }

        private bool EventExists(int id)
        {
            return _context.Event.Any(e => e.EventID == id);
        }
    }
}
