﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LuTypesController : ControllerBase
    {
        private readonly NewDBContext _context;

        public LuTypesController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/LuTypes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<LuType>>> GetLuType()
        {
            return await _context.LuType.ToListAsync();
        }

        // GET: api/LuTypes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<LuType>> GetLuType(int id)
        {
            var luType = await _context.LuType.FindAsync(id);

            if (luType == null)
            {
                return NotFound();
            }

            return luType;
        }

        // PUT: api/LuTypes/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutLuType(LuType luType)
        {
            //if (id != luType.LuTypeID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(luType).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!LuTypeExists(Convert.ToInt32(luType.LuTypeID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/LuTypes
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<LuType>> PostLuType(LuType luType)
        {
            _context.LuType.Add(luType);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetLuType", new { id = luType.LuTypeID }, luType);
        }

        // DELETE: api/LuTypes/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<LuType>> DeleteLuType(int id)
        {
            var luType = await _context.LuType.FindAsync(id);
            if (luType == null)
            {
                return NotFound();
            }

            _context.LuType.Remove(luType);
            await _context.SaveChangesAsync();

            return luType;
        }

        private bool LuTypeExists(int id)
        {
            return _context.LuType.Any(e => e.LuTypeID == id);
        }
    }
}
