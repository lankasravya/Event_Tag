﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventPlatformV3.Models;
using EventPlatformV3.Data;

namespace EventPlatformV3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Event_GenreController : ControllerBase
    {
        private readonly NewDBContext _context;

        public Event_GenreController(NewDBContext context)
        {
            _context = context;
        }

        // GET: api/Event_Genre
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Event_Genre>>> GetEvent_Genre()
        {
            return await _context.Event_Genre.Include("Event").Include("Genre").ToListAsync();
        }

        // GET: api/Event_Genre
        [HttpGet("{id}")]
        public async Task<ActionResult<Event_Genre>> GetEvent_Genre(int id)
        {
            await _context.Event_Genre.Include("Event").Include("Genre").ToListAsync();
            var event_Genre = await _context.Event_Genre.FindAsync(id);

            if (event_Genre == null)
            {
                return NotFound();
            }

            return event_Genre;
        }


        [HttpGet("{eventId}")]
        [Route("EventGenreByEventId/{eventId}")]
        public async Task<ActionResult<IEnumerable<Event_Genre>>> GetEventGenreByEvent(int eventId)
        {
            //await _context.Event_Genre.Include("Event").Include("Genre").ToListAsync();
            var event_Genre = await _context.Event_Genre.Include("Genre").Where(x => x.EventID == eventId).ToListAsync();

            if (event_Genre == null)
            {
                return NotFound();
            }

            return event_Genre;
        }


        //[HttpPost]
        //[Route("GetEvent_GenresByEventID")]
        //public async Task<ActionResult<IEnumerable<Event_Genre>>> GetEvent_Genre(Event_Genre event_Genre)
        //{
        //    // var eventEdition_Location =await _context.EventEdition_Location.FindAsync(eventEdition);
        //    if (event_Genre.EventID != null)
        //    {

        //        var Event_Genre = _context.Event_Genre.Where(x => x.EventID == event_Genre.EventID).ToList();
        //        return Event_Genre;
        //    }

        //    else
        //        return null;
        //}


        // PUT: api/Event_Genre/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut]
        public async Task<IActionResult> PutEvent_Genre(Event_Genre event_Genre)
        {
            //if (id != event_Genre.Event_GenreID)
            //{
            //    return BadRequest();
            //}

            _context.Entry(event_Genre).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Event_GenreExists(Convert.ToInt32(event_Genre.Event_GenreID)))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Event_Genre
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        //[HttpPost]
        //public async Task<ActionResult<Event_Genre>> PostEvent_Genre(Event_Genre event_Genre)
        //{
        //    _context.Event_Genre.Add(event_Genre);
        //    await _context.SaveChangesAsync();

        //    return CreatedAtAction("GetEvent_Genre", new { id = event_Genre.Event_GenreID }, event_Genre);
        //}

        // POST: api/Event_Genre
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<IEnumerable<Event_Genre>>> PostEvent_Genre(Event_Genre event_Genre)
        {
            
            _context.Event_Genre.Add(event_Genre);
            await _context.SaveChangesAsync();

            //return CreatedAtAction("GetEvent_Genre", new { id = event_Genre.Event_GenreID }, event_Genre);
            return await _context.Event_Genre.Where(x => x.EventID == event_Genre.EventID).ToListAsync();
        }



        // DELETE: api/Event_Genre/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Event_Genre>> DeleteEvent_Genre(int id)
        {
            var event_Genre = await _context.Event_Genre.FindAsync(id);
            if (event_Genre == null)
            {
                return NotFound();
            }

            _context.Event_Genre.Remove(event_Genre);
            await _context.SaveChangesAsync();

            return event_Genre;
        }

        private bool Event_GenreExists(int id)
        {
            return _context.Event_Genre.Any(e => e.Event_GenreID == id);
        }
    }
}
